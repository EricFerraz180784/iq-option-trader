"""
Utilitários de segurança
Criptografia de credenciais e dados sensíveis
"""

import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2
from typing import Optional

class SecurityManager:
    """Gerenciador de segurança e criptografia"""
    
    def __init__(self, key: Optional[str] = None):
        """
        Inicializa gerenciador de segurança
        
        Args:
            key: Chave de criptografia (será gerada se não fornecida)
        """
        if key:
            self._key = key.encode()
        else:
            self._key = Fernet.generate_key()
        
        self._fernet = Fernet(self._key)
    
    def encrypt(self, data: str) -> str:
        """
        Criptografa string
        
        Args:
            data: Dados para criptografar
        
        Returns:
            String criptografada em base64
        """
        encrypted = self._fernet.encrypt(data.encode())
        return base64.urlsafe_b64encode(encrypted).decode()
    
    def decrypt(self, encrypted_data: str) -> str:
        """
        Descriptografa string
        
        Args:
            encrypted_data: Dados criptografados em base64
        
        Returns:
            String descriptografada
        """
        decoded = base64.urlsafe_b64decode(encrypted_data.encode())
        decrypted = self._fernet.decrypt(decoded)
        return decrypted.decode()
    
    @staticmethod
    def generate_key() -> str:
        """Gera nova chave de criptografia"""
        return Fernet.generate_key().decode()
    
    @staticmethod
    def derive_key_from_password(password: str, salt: bytes) -> bytes:
        """
        Deriva chave a partir de senha
        
        Args:
            password: Senha
            salt: Salt para derivação
        
        Returns:
            Chave derivada
        """
        kdf = PBKDF2(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password.encode()))

def mask_sensitive_data(data: str, visible_chars: int = 4) -> str:
    """
    Mascara dados sensíveis mantendo apenas alguns caracteres visíveis
    
    Args:
        data: Dados para mascarar
        visible_chars: Número de caracteres visíveis no início e fim
    
    Returns:
        String mascarada
    """
    if len(data) <= visible_chars * 2:
        return '*' * len(data)
    
    return f"{data[:visible_chars]}{'*' * (len(data) - visible_chars * 2)}{data[-visible_chars:]}"