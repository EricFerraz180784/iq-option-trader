"""
Utilitários do sistema
"""