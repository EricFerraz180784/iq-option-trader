"""
Sistema de Gestão de Risco
Controla exposição, limites de perda e proteção de capital
"""

import asyncio
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from ..utils.logger import setup_logger
from ..core.config import Config

logger = setup_logger(__name__, Config.LOG_FILE, Config.LOG_LEVEL)


class RiskManager:
    """Gerenciador de risco para trading automatizado"""
    
    def __init__(
        self,
        max_position_size: float = 0.02,  # 2% do capital por operação
        max_daily_loss: float = 0.05,     # 5% de perda diária máxima
        max_daily_trades: int = 20,       # Máximo de trades por dia
        stop_loss_pct: float = 0.02,      # 2% stop loss
        take_profit_pct: float = 0.04     # 4% take profit
    ):
        """
        Inicializa o gerenciador de risco
        
        Args:
            max_position_size: Tamanho máximo da posição (% do capital)
            max_daily_loss: Perda diária máxima (% do capital)
            max_daily_trades: Número máximo de trades por dia
            stop_loss_pct: Percentual de stop loss
            take_profit_pct: Percentual de take profit
        """
        self.max_position_size = max_position_size
        self.max_daily_loss = max_daily_loss
        self.max_daily_trades = max_daily_trades
        self.stop_loss_pct = stop_loss_pct
        self.take_profit_pct = take_profit_pct
        
        # Estado do dia
        self.daily_pnl = 0.0
        self.daily_trades = 0
        self.last_reset = datetime.now().date()
        
        # Posições abertas
        self.open_positions: Dict[str, Dict] = {}
        
        # Histórico
        self.trade_history: List[Dict] = []
        self.alerts: List[Dict] = []
    
    async def reset_daily_stats(self) -> None:
        """Reseta estatísticas diárias"""
        current_date = datetime.now().date()
        
        if current_date > self.last_reset:
            logger.info("Resetando estatísticas diárias")
            self.daily_pnl = 0.0
            self.daily_trades = 0
            self.last_reset = current_date
            
            await self._add_alert("info", "Estatísticas diárias resetadas")
    
    async def can_open_position(
        self, 
        balance: float, 
        amount: float
    ) -> Tuple[bool, str]:
        """
        Verifica se pode abrir uma nova posição
        
        Args:
            balance: Saldo atual da conta
            amount: Valor da operação
            
        Returns:
            Tupla (pode_operar, motivo)
        """
        await self.reset_daily_stats()
        
        # Verificar perda diária
        if self.daily_pnl < 0:
            daily_loss_pct = abs(self.daily_pnl) / balance
            if daily_loss_pct >= self.max_daily_loss:
                reason = f"Limite de perda diária atingido ({daily_loss_pct*100:.2f}%)"
                await self._add_alert("danger", reason)
                return False, reason
        
        # Verificar número de trades
        if self.daily_trades >= self.max_daily_trades:
            reason = f"Limite de trades diários atingido ({self.daily_trades})"
            await self._add_alert("warning", reason)
            return False, reason
        
        # Verificar tamanho da posição
        position_size = amount / balance
        if position_size > self.max_position_size:
            reason = f"Tamanho da posição excede o limite ({position_size*100:.2f}% > {self.max_position_size*100:.2f}%)"
            await self._add_alert("warning", reason)
            return False, reason
        
        # Verificar se já tem muitas posições abertas
        if len(self.open_positions) >= 5:
            reason = "Número máximo de posições abertas atingido"
            await self._add_alert("warning", reason)
            return False, reason
        
        return True, "OK"
    
    async def calculate_position_size(
        self, 
        balance: float, 
        risk_per_trade: Optional[float] = None
    ) -> float:
        """
        Calcula o tamanho ideal da posição
        
        Args:
            balance: Saldo atual
            risk_per_trade: Risco por trade (opcional)
            
        Returns:
            Valor da posição
        """
        risk = risk_per_trade if risk_per_trade else self.max_position_size
        position_size = balance * risk
        
        # Arredondar para 2 casas decimais
        return round(position_size, 2)
    
    async def calculate_stop_loss(
        self, 
        entry_price: float, 
        direction: str
    ) -> float:
        """
        Calcula preço de stop loss
        
        Args:
            entry_price: Preço de entrada
            direction: "BUY" ou "SELL"
            
        Returns:
            Preço de stop loss
        """
        if direction == "BUY":
            stop_loss = entry_price * (1 - self.stop_loss_pct)
        else:  # SELL
            stop_loss = entry_price * (1 + self.stop_loss_pct)
        
        return round(stop_loss, 5)
    
    async def calculate_take_profit(
        self, 
        entry_price: float, 
        direction: str
    ) -> float:
        """
        Calcula preço de take profit
        
        Args:
            entry_price: Preço de entrada
            direction: "BUY" ou "SELL"
            
        Returns:
            Preço de take profit
        """
        if direction == "BUY":
            take_profit = entry_price * (1 + self.take_profit_pct)
        else:  # SELL
            take_profit = entry_price * (1 - self.take_profit_pct)
        
        return round(take_profit, 5)
    
    async def open_position(
        self,
        position_id: str,
        asset: str,
        direction: str,
        entry_price: float,
        amount: float
    ) -> Dict:
        """
        Registra abertura de posição
        
        Args:
            position_id: ID da posição
            asset: Ativo negociado
            direction: "BUY" ou "SELL"
            entry_price: Preço de entrada
            amount: Valor da operação
            
        Returns:
            Dados da posição
        """
        stop_loss = await self.calculate_stop_loss(entry_price, direction)
        take_profit = await self.calculate_take_profit(entry_price, direction)
        
        position = {
            "id": position_id,
            "asset": asset,
            "direction": direction,
            "entry_price": entry_price,
            "amount": amount,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "opened_at": datetime.now().isoformat(),
            "status": "OPEN"
        }
        
        self.open_positions[position_id] = position
        self.daily_trades += 1
        
        logger.info(f"Posição aberta: {position_id} - {direction} {asset} @ {entry_price}")
        await self._add_alert("success", f"Posição aberta: {direction} {asset}")
        
        return position
    
    async def close_position(
        self,
        position_id: str,
        exit_price: float,
        reason: str = "Manual"
    ) -> Optional[Dict]:
        """
        Fecha uma posição e calcula P&L
        
        Args:
            position_id: ID da posição
            exit_price: Preço de saída
            reason: Motivo do fechamento
            
        Returns:
            Resultado da operação
        """
        if position_id not in self.open_positions:
            logger.warning(f"Posição {position_id} não encontrada")
            return None
        
        position = self.open_positions[position_id]
        
        # Calcular P&L
        if position["direction"] == "BUY":
            pnl = (exit_price - position["entry_price"]) * position["amount"] / position["entry_price"]
        else:  # SELL
            pnl = (position["entry_price"] - exit_price) * position["amount"] / position["entry_price"]
        
        pnl_pct = (pnl / position["amount"]) * 100
        
        # Atualizar estatísticas
        self.daily_pnl += pnl
        
        # Criar registro de fechamento
        result = {
            **position,
            "exit_price": exit_price,
            "pnl": round(pnl, 2),
            "pnl_pct": round(pnl_pct, 2),
            "closed_at": datetime.now().isoformat(),
            "close_reason": reason,
            "status": "CLOSED"
        }
        
        # Adicionar ao histórico
        self.trade_history.append(result)
        
        # Remover das posições abertas
        del self.open_positions[position_id]
        
        # Log e alerta
        logger.info(f"Posição fechada: {position_id} - P&L: {pnl:.2f} ({pnl_pct:.2f}%)")
        
        alert_type = "success" if pnl > 0 else "danger"
        await self._add_alert(
            alert_type, 
            f"Posição fechada: {position['direction']} {position['asset']} - P&L: {pnl:.2f}"
        )
        
        return result
    
    async def check_stop_loss_take_profit(
        self,
        current_prices: Dict[str, float]
    ) -> List[Dict]:
        """
        Verifica se alguma posição atingiu stop loss ou take profit
        
        Args:
            current_prices: Dicionário com preços atuais {asset: price}
            
        Returns:
            Lista de posições que devem ser fechadas
        """
        to_close = []
        
        for position_id, position in list(self.open_positions.items()):
            asset = position["asset"]
            
            if asset not in current_prices:
                continue
            
            current_price = current_prices[asset]
            
            # Verificar stop loss
            if position["direction"] == "BUY":
                if current_price <= position["stop_loss"]:
                    result = await self.close_position(position_id, current_price, "Stop Loss")
                    to_close.append(result)
                    continue
                
                if current_price >= position["take_profit"]:
                    result = await self.close_position(position_id, current_price, "Take Profit")
                    to_close.append(result)
                    continue
            
            else:  # SELL
                if current_price >= position["stop_loss"]:
                    result = await self.close_position(position_id, current_price, "Stop Loss")
                    to_close.append(result)
                    continue
                
                if current_price <= position["take_profit"]:
                    result = await self.close_position(position_id, current_price, "Take Profit")
                    to_close.append(result)
                    continue
        
        return to_close
    
    async def get_statistics(self) -> Dict:
        """
        Retorna estatísticas de risco e performance
        
        Returns:
            Dicionário com estatísticas
        """
        total_trades = len(self.trade_history)
        
        if total_trades == 0:
            return {
                "total_trades": 0,
                "win_rate": 0.0,
                "avg_profit": 0.0,
                "avg_loss": 0.0,
                "profit_factor": 0.0,
                "daily_pnl": self.daily_pnl,
                "daily_trades": self.daily_trades,
                "open_positions": len(self.open_positions)
            }
        
        wins = [t for t in self.trade_history if t["pnl"] > 0]
        losses = [t for t in self.trade_history if t["pnl"] < 0]
        
        win_rate = (len(wins) / total_trades) * 100
        avg_profit = sum(t["pnl"] for t in wins) / len(wins) if wins else 0
        avg_loss = sum(t["pnl"] for t in losses) / len(losses) if losses else 0
        
        total_profit = sum(t["pnl"] for t in wins)
        total_loss = abs(sum(t["pnl"] for t in losses))
        profit_factor = total_profit / total_loss if total_loss > 0 else 0
        
        return {
            "total_trades": total_trades,
            "winning_trades": len(wins),
            "losing_trades": len(losses),
            "win_rate": round(win_rate, 2),
            "avg_profit": round(avg_profit, 2),
            "avg_loss": round(avg_loss, 2),
            "profit_factor": round(profit_factor, 2),
            "daily_pnl": round(self.daily_pnl, 2),
            "daily_trades": self.daily_trades,
            "open_positions": len(self.open_positions),
            "max_daily_loss_pct": self.max_daily_loss * 100,
            "max_daily_trades": self.max_daily_trades
        }
    
    async def get_alerts(self, limit: int = 10) -> List[Dict]:
        """Retorna alertas recentes"""
        return self.alerts[-limit:]
    
    async def _add_alert(self, alert_type: str, message: str) -> None:
        """Adiciona um alerta ao sistema"""
        alert = {
            "type": alert_type,
            "message": message,
            "timestamp": datetime.now().isoformat()
        }
        
        self.alerts.append(alert)
        
        # Manter apenas últimos 100 alertas
        if len(self.alerts) > 100:
            self.alerts = self.alerts[-100:]