"""
Sistema de Execução Automática de Trades
Executa operações automaticamente baseado em sinais de análise técnica
"""

import asyncio
import uuid
from typing import Dict, Optional, List
from datetime import datetime
from ..utils.logger import setup_logger
from ..core.config import Config
from .iq_option_service import IQOptionService
from .technical_analysis import TechnicalAnalysis
from .risk_manager import RiskManager

logger = setup_logger(__name__, Config.LOG_FILE, Config.LOG_LEVEL)


class AutoTrader:
    """Sistema de trading automatizado"""
    
    def __init__(
        self,
        iq_service: IQOptionService,
        technical_analysis: TechnicalAnalysis,
        risk_manager: RiskManager
    ):
        """
        Inicializa o auto trader
        
        Args:
            iq_service: Serviço de conexão com IQ Option
            technical_analysis: Sistema de análise técnica
            risk_manager: Gerenciador de risco
        """
        self.iq_service = iq_service
        self.technical_analysis = technical_analysis
        self.risk_manager = risk_manager
        
        # Configurações
        self.is_running = False
        self.mode = "SIMULATION"  # SIMULATION ou REAL
        self.active_assets = ["EURUSD", "GBPUSD", "USDJPY"]
        self.timeframe = 60  # segundos
        self.min_confidence = 70.0  # Confiança mínima para executar trade
        
        # Estado
        self.last_signals: Dict[str, Dict] = {}
        self.execution_log: List[Dict] = []
    
    async def start(self, mode: str = "SIMULATION") -> bool:
        """
        Inicia o sistema de trading automático
        
        Args:
            mode: "SIMULATION" ou "REAL"
            
        Returns:
            True se iniciado com sucesso
        """
        try:
            self.mode = mode
            self.is_running = True
            
            logger.info(f"Auto Trader iniciado em modo {mode}")
            logger.info(f"Ativos ativos: {', '.join(self.active_assets)}")
            logger.info(f"Confiança mínima: {self.min_confidence}%")
            
            return True
            
        except Exception as e:
            logger.error(f"Erro ao iniciar Auto Trader: {str(e)}")
            return False
    
    async def stop(self) -> None:
        """Para o sistema de trading automático"""
        self.is_running = False
        logger.info("Auto Trader parado")
    
    async def analyze_and_trade(self, asset: str) -> Optional[Dict]:
        """
        Analisa um ativo e executa trade se houver sinal
        
        Args:
            asset: Nome do ativo
            
        Returns:
            Resultado da análise e execução
        """
        try:
            if not self.is_running:
                return None
            
            # Obter dados históricos
            candles = await self.iq_service.get_candles(asset, self.timeframe, 200)
            
            if not candles or len(candles) < 50:
                logger.warning(f"Dados insuficientes para {asset}")
                return None
            
            # Extrair preços e volumes
            prices = [c["close"] for c in candles]
            volumes = [c.get("volume", 1000) for c in candles]
            
            # Gerar sinal
            signal_data = await self.technical_analysis.generate_signal(
                prices, volumes, candles
            )
            
            # Armazenar último sinal
            self.last_signals[asset] = signal_data
            
            # Verificar se deve executar trade
            signal = signal_data["signal"]
            confidence = signal_data["confidence"]
            
            if signal == "HOLD" or confidence < self.min_confidence:
                logger.debug(f"{asset}: {signal} (confiança: {confidence}%) - Não executando")
                return signal_data
            
            # Obter saldo
            balance = await self.iq_service.get_balance()
            
            # Calcular tamanho da posição
            position_size = await self.risk_manager.calculate_position_size(balance)
            
            # Verificar se pode abrir posição
            can_trade, reason = await self.risk_manager.can_open_position(balance, position_size)
            
            if not can_trade:
                logger.warning(f"Não pode abrir posição: {reason}")
                signal_data["execution_blocked"] = reason
                return signal_data
            
            # Executar trade
            if self.mode == "REAL":
                result = await self._execute_real_trade(
                    asset, signal, position_size, prices[-1]
                )
            else:
                result = await self._execute_simulated_trade(
                    asset, signal, position_size, prices[-1]
                )
            
            signal_data["execution"] = result
            
            return signal_data
            
        except Exception as e:
            logger.error(f"Erro ao analisar e operar {asset}: {str(e)}")
            return None
    
    async def _execute_real_trade(
        self,
        asset: str,
        direction: str,
        amount: float,
        current_price: float
    ) -> Dict:
        """
        Executa trade real na IQ Option
        
        Args:
            asset: Ativo
            direction: "BUY" ou "SELL"
            amount: Valor da operação
            current_price: Preço atual
            
        Returns:
            Resultado da execução
        """
        try:
            # Aqui você implementaria a chamada real para a API da IQ Option
            # Por enquanto, vamos simular
            
            position_id = str(uuid.uuid4())
            
            # Registrar no risk manager
            position = await self.risk_manager.open_position(
                position_id, asset, direction, current_price, amount
            )
            
            result = {
                "status": "SUCCESS",
                "position_id": position_id,
                "asset": asset,
                "direction": direction,
                "entry_price": current_price,
                "amount": amount,
                "stop_loss": position["stop_loss"],
                "take_profit": position["take_profit"],
                "mode": "REAL",
                "timestamp": datetime.now().isoformat()
            }
            
            self.execution_log.append(result)
            logger.info(f"Trade REAL executado: {direction} {asset} @ {current_price}")
            
            return result
            
        except Exception as e:
            logger.error(f"Erro ao executar trade real: {str(e)}")
            return {
                "status": "ERROR",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    async def _execute_simulated_trade(
        self,
        asset: str,
        direction: str,
        amount: float,
        current_price: float
    ) -> Dict:
        """
        Executa trade simulado (paper trading)
        
        Args:
            asset: Ativo
            direction: "BUY" ou "SELL"
            amount: Valor da operação
            current_price: Preço atual
            
        Returns:
            Resultado da execução
        """
        try:
            position_id = str(uuid.uuid4())
            
            # Registrar no risk manager
            position = await self.risk_manager.open_position(
                position_id, asset, direction, current_price, amount
            )
            
            result = {
                "status": "SUCCESS",
                "position_id": position_id,
                "asset": asset,
                "direction": direction,
                "entry_price": current_price,
                "amount": amount,
                "stop_loss": position["stop_loss"],
                "take_profit": position["take_profit"],
                "mode": "SIMULATION",
                "timestamp": datetime.now().isoformat()
            }
            
            self.execution_log.append(result)
            logger.info(f"Trade SIMULADO executado: {direction} {asset} @ {current_price}")
            
            return result
            
        except Exception as e:
            logger.error(f"Erro ao executar trade simulado: {str(e)}")
            return {
                "status": "ERROR",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    async def monitor_positions(self) -> List[Dict]:
        """
        Monitora posições abertas e fecha se atingir stop/take profit
        
        Returns:
            Lista de posições fechadas
        """
        try:
            # Obter preços atuais de todos os ativos
            current_prices = {}
            
            for asset in self.active_assets:
                candles = await self.iq_service.get_candles(asset, self.timeframe, 1)
                if candles:
                    current_prices[asset] = candles[-1]["close"]
            
            # Verificar stop loss e take profit
            closed_positions = await self.risk_manager.check_stop_loss_take_profit(
                current_prices
            )
            
            return closed_positions
            
        except Exception as e:
            logger.error(f"Erro ao monitorar posições: {str(e)}")
            return []
    
    async def get_status(self) -> Dict:
        """
        Retorna status do auto trader
        
        Returns:
            Dicionário com status completo
        """
        statistics = await self.risk_manager.get_statistics()
        
        return {
            "is_running": self.is_running,
            "mode": self.mode,
            "active_assets": self.active_assets,
            "timeframe": self.timeframe,
            "min_confidence": self.min_confidence,
            "last_signals": self.last_signals,
            "statistics": statistics,
            "recent_executions": self.execution_log[-10:] if self.execution_log else []
        }
    
    async def update_config(self, config: Dict) -> bool:
        """
        Atualiza configurações do auto trader
        
        Args:
            config: Dicionário com novas configurações
            
        Returns:
            True se atualizado com sucesso
        """
        try:
            if "mode" in config:
                self.mode = config["mode"]
            
            if "active_assets" in config:
                self.active_assets = config["active_assets"]
            
            if "timeframe" in config:
                self.timeframe = config["timeframe"]
            
            if "min_confidence" in config:
                self.min_confidence = config["min_confidence"]
            
            logger.info(f"Configurações atualizadas: {config}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao atualizar configurações: {str(e)}")
            return False