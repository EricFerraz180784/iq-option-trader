"""
Sistema de Backtesting
Testa estratégias com dados históricos
"""

import asyncio
import numpy as np
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from ..utils.logger import setup_logger
from ..core.config import Config

logger = setup_logger(__name__, Config.LOG_FILE, Config.LOG_LEVEL)


class Backtester:
    """Sistema de backtesting para estratégias de trading"""
    
    def __init__(self):
        """Inicializa o backtester"""
        self.results = []
        self.equity_curve = []
    
    async def run_backtest(
        self,
        iq_service,
        technical_analysis,
        risk_manager,
        asset: str,
        start_balance: float = 10000.0,
        periods: int = 1000,
        timeframe: int = 60
    ) -> Dict:
        """
        Executa backtest de estratégia
        
        Args:
            iq_service: Serviço IQ Option
            technical_analysis: Sistema de análise técnica
            risk_manager: Gerenciador de risco
            asset: Ativo para testar
            start_balance: Saldo inicial
            periods: Número de períodos
            timeframe: Timeframe em segundos
            
        Returns:
            Resultados do backtest
        """
        try:
            logger.info(f"Iniciando backtest para {asset}...")
            logger.info(f"Saldo inicial: ${start_balance}")
            logger.info(f"Períodos: {periods}, Timeframe: {timeframe}s")
            
            # Obter dados históricos
            candles = await iq_service.get_candles(asset, timeframe, periods + 200)
            
            if not candles or len(candles) < periods:
                logger.error("Dados históricos insuficientes")
                return {"error": "Dados insuficientes"}
            
            # Variáveis de simulação
            balance = start_balance
            position = None
            trades = []
            equity = [balance]
            
            # Simular trading
            for i in range(200, len(candles)):
                window = candles[i-200:i]
                current_candle = candles[i]
                current_price = current_candle["close"]
                
                # Preparar dados
                prices = [c["close"] for c in window]
                volumes = [c.get("volume", 1000) for c in window]
                
                # Gerar sinal
                signal_data = await technical_analysis.generate_signal(
                    prices, volumes, window
                )
                
                signal = signal_data["signal"]
                confidence = signal_data["confidence"]
                
                # Se tem posição aberta, verificar saída
                if position:
                    # Calcular P&L
                    if position["direction"] == "BUY":
                        pnl = (current_price - position["entry_price"]) * position["amount"] / position["entry_price"]
                        
                        # Stop loss ou take profit
                        if current_price <= position["stop_loss"] or current_price >= position["take_profit"]:
                            balance += pnl
                            
                            trades.append({
                                "entry_price": position["entry_price"],
                                "exit_price": current_price,
                                "direction": position["direction"],
                                "pnl": pnl,
                                "pnl_pct": (pnl / position["amount"]) * 100,
                                "bars_held": i - position["entry_bar"]
                            })
                            
                            position = None
                    
                    else:  # SELL
                        pnl = (position["entry_price"] - current_price) * position["amount"] / position["entry_price"]
                        
                        if current_price >= position["stop_loss"] or current_price <= position["take_profit"]:
                            balance += pnl
                            
                            trades.append({
                                "entry_price": position["entry_price"],
                                "exit_price": current_price,
                                "direction": position["direction"],
                                "pnl": pnl,
                                "pnl_pct": (pnl / position["amount"]) * 100,
                                "bars_held": i - position["entry_bar"]
                            })
                            
                            position = None
                
                # Se não tem posição, verificar entrada
                if not position and signal in ["BUY", "SELL"] and confidence >= 70:
                    # Calcular tamanho da posição
                    position_size = balance * 0.02  # 2% do capital
                    
                    # Verificar se pode abrir
                    can_trade, _ = await risk_manager.can_open_position(balance, position_size)
                    
                    if can_trade:
                        stop_loss = await risk_manager.calculate_stop_loss(current_price, signal)
                        take_profit = await risk_manager.calculate_take_profit(current_price, signal)
                        
                        position = {
                            "direction": signal,
                            "entry_price": current_price,
                            "entry_bar": i,
                            "amount": position_size,
                            "stop_loss": stop_loss,
                            "take_profit": take_profit
                        }
                
                # Atualizar equity curve
                current_equity = balance
                if position:
                    if position["direction"] == "BUY":
                        unrealized_pnl = (current_price - position["entry_price"]) * position["amount"] / position["entry_price"]
                    else:
                        unrealized_pnl = (position["entry_price"] - current_price) * position["amount"] / position["entry_price"]
                    current_equity += unrealized_pnl
                
                equity.append(current_equity)
            
            # Calcular métricas
            metrics = await self._calculate_metrics(trades, equity, start_balance)
            
            logger.info(f"Backtest concluído: {len(trades)} trades")
            logger.info(f"Retorno total: {metrics['total_return_pct']:.2f}%")
            logger.info(f"Win rate: {metrics['win_rate']:.2f}%")
            
            return {
                "asset": asset,
                "start_balance": start_balance,
                "end_balance": balance,
                "total_trades": len(trades),
                "trades": trades,
                "equity_curve": equity,
                "metrics": metrics,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Erro no backtest: {str(e)}")
            return {"error": str(e)}
    
    async def _calculate_metrics(
        self,
        trades: List[Dict],
        equity_curve: List[float],
        start_balance: float
    ) -> Dict:
        """Calcula métricas de performance"""
        try:
            if not trades:
                return {
                    "total_trades": 0,
                    "win_rate": 0.0,
                    "total_return_pct": 0.0,
                    "sharpe_ratio": 0.0,
                    "max_drawdown_pct": 0.0
                }
            
            # Trades vencedores e perdedores
            wins = [t for t in trades if t["pnl"] > 0]
            losses = [t for t in trades if t["pnl"] < 0]
            
            # Win rate
            win_rate = (len(wins) / len(trades)) * 100 if trades else 0
            
            # Retorno total
            end_balance = equity_curve[-1]
            total_return = end_balance - start_balance
            total_return_pct = (total_return / start_balance) * 100
            
            # Profit factor
            total_profit = sum(t["pnl"] for t in wins)
            total_loss = abs(sum(t["pnl"] for t in losses))
            profit_factor = total_profit / total_loss if total_loss > 0 else 0
            
            # Sharpe ratio
            returns = np.diff(equity_curve) / equity_curve[:-1]
            sharpe_ratio = (np.mean(returns) / np.std(returns)) * np.sqrt(252) if np.std(returns) > 0 else 0
            
            # Max drawdown
            peak = equity_curve[0]
            max_dd = 0
            for value in equity_curve:
                if value > peak:
                    peak = value
                dd = (peak - value) / peak
                if dd > max_dd:
                    max_dd = dd
            
            max_drawdown_pct = max_dd * 100
            
            # Médias
            avg_win = np.mean([t["pnl"] for t in wins]) if wins else 0
            avg_loss = np.mean([t["pnl"] for t in losses]) if losses else 0
            avg_bars_held = np.mean([t["bars_held"] for t in trades])
            
            return {
                "total_trades": len(trades),
                "winning_trades": len(wins),
                "losing_trades": len(losses),
                "win_rate": round(win_rate, 2),
                "total_return": round(total_return, 2),
                "total_return_pct": round(total_return_pct, 2),
                "profit_factor": round(profit_factor, 2),
                "sharpe_ratio": round(sharpe_ratio, 2),
                "max_drawdown_pct": round(max_drawdown_pct, 2),
                "avg_win": round(avg_win, 2),
                "avg_loss": round(avg_loss, 2),
                "avg_bars_held": round(avg_bars_held, 1)
            }
            
        except Exception as e:
            logger.error(f"Erro ao calcular métricas: {str(e)}")
            return {}
    
    async def optimize_parameters(
        self,
        iq_service,
        technical_analysis,
        risk_manager,
        asset: str,
        parameter_ranges: Dict
    ) -> Dict:
        """
        Otimiza parâmetros da estratégia
        
        Args:
            iq_service: Serviço IQ Option
            technical_analysis: Sistema de análise técnica
            risk_manager: Gerenciador de risco
            asset: Ativo para otimizar
            parameter_ranges: Ranges de parâmetros para testar
            
        Returns:
            Melhores parâmetros encontrados
        """
        logger.info("Iniciando otimização de parâmetros...")
        
        best_result = None
        best_sharpe = -999
        
        # Grid search simplificado
        for min_conf in parameter_ranges.get("min_confidence", [60, 70, 80]):
            for stop_loss in parameter_ranges.get("stop_loss_pct", [0.01, 0.02, 0.03]):
                for take_profit in parameter_ranges.get("take_profit_pct", [0.02, 0.04, 0.06]):
                    # Atualizar parâmetros
                    risk_manager.stop_loss_pct = stop_loss
                    risk_manager.take_profit_pct = take_profit
                    
                    # Executar backtest
                    result = await self.run_backtest(
                        iq_service,
                        technical_analysis,
                        risk_manager,
                        asset
                    )
                    
                    if "metrics" in result:
                        sharpe = result["metrics"].get("sharpe_ratio", -999)
                        
                        if sharpe > best_sharpe:
                            best_sharpe = sharpe
                            best_result = {
                                "min_confidence": min_conf,
                                "stop_loss_pct": stop_loss,
                                "take_profit_pct": take_profit,
                                "sharpe_ratio": sharpe,
                                "metrics": result["metrics"]
                            }
        
        logger.info(f"Otimização concluída. Melhor Sharpe: {best_sharpe:.2f}")
        return best_result