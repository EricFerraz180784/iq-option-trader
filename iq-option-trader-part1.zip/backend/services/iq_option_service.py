"""
Serviço de integração com IQ Option
Gerencia conexão, autenticação e operações de trading
"""

import asyncio
from typing import Optional, Dict, Any
from iqoptionapi.stable_api import IQ_Option
from ..utils.logger import setup_logger
from ..core.config import Config

logger = setup_logger(__name__, Config.LOG_FILE, Config.LOG_LEVEL)

class IQOptionService:
    """Serviço de integração com IQ Option"""
    
    def __init__(self, email: str, password: str):
        """
        Inicializa serviço IQ Option
        
        Args:
            email: Email da conta
            password: Senha da conta
        """
        self.email = email
        self.password = password
        self.api: Optional[IQ_Option] = None
        self._connected = False
        self._reconnect_attempts = 0
    
    async def connect(self) -> bool:
        """
        Conecta à API do IQ Option
        
        Returns:
            True se conectado com sucesso
        """
        try:
            logger.info("Iniciando conexão com IQ Option...")
            
            # Executar conexão em thread separada (API é síncrona)
            loop = asyncio.get_event_loop()
            self.api = await loop.run_in_executor(
                None,
                lambda: IQ_Option(self.email, self.password)
            )
            
            check, reason = await loop.run_in_executor(
                None,
                self.api.connect
            )
            
            if check:
                logger.info("✓ Conectado ao IQ Option com sucesso")
                self._connected = True
                self._reconnect_attempts = 0
                
                # Configurar tipo de conta
                await loop.run_in_executor(
                    None,
                    lambda: self.api.change_balance(Config.BALANCE_TYPE)
                )
                logger.info(f"Tipo de conta: {Config.BALANCE_TYPE}")
                
                return True
            else:
                logger.error(f"✗ Falha na autenticação: {reason}")
                self._connected = False
                return False
                
        except Exception as e:
            logger.error(f"✗ Erro ao conectar: {str(e)}")
            self._connected = False
            return False
    
    async def disconnect(self) -> None:
        """Desconecta da API"""
        if self.api:
            try:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, self.api.close)
                logger.info("Desconectado do IQ Option")
            except Exception as e:
                logger.error(f"Erro ao desconectar: {str(e)}")
            finally:
                self._connected = False
    
    async def check_connection(self) -> bool:
        """
        Verifica se ainda está conectado
        
        Returns:
            True se conectado
        """
        if not self.api:
            return False
        
        try:
            loop = asyncio.get_event_loop()
            is_connected = await loop.run_in_executor(
                None,
                self.api.check_connect
            )
            self._connected = is_connected
            return is_connected
        except Exception as e:
            logger.error(f"Erro ao verificar conexão: {str(e)}")
            self._connected = False
            return False
    
    async def get_balance(self) -> float:
        """
        Obtém saldo da conta
        
        Returns:
            Saldo atual
        """
        if not self._connected or not self.api:
            return 0.0
        
        try:
            loop = asyncio.get_event_loop()
            balance = await loop.run_in_executor(
                None,
                self.api.get_balance
            )
            return float(balance) if balance else 0.0
        except Exception as e:
            logger.error(f"Erro ao obter saldo: {str(e)}")
            return 0.0
    
    async def get_candles(self, asset: str, duration: int = 60, count: int = 100) -> list:
        """
        Obtém dados de candles
        
        Args:
            asset: Nome do ativo (ex: "EURUSD")
            duration: Duração do candle em segundos
            count: Quantidade de candles
        
        Returns:
            Lista de candles
        """
        if not self._connected or not self.api:
            return []
        
        try:
            loop = asyncio.get_event_loop()
            candles = await loop.run_in_executor(
                None,
                lambda: self.api.get_candles(asset, duration, count, time.time())
            )
            return candles if candles else []
        except Exception as e:
            logger.error(f"Erro ao obter candles: {str(e)}")
            return []
    
    async def auto_reconnect(self) -> bool:
        """
        Tenta reconectar automaticamente
        
        Returns:
            True se reconectado com sucesso
        """
        if not Config.AUTO_RECONNECT:
            return False
        
        if self._reconnect_attempts >= Config.MAX_RECONNECT_ATTEMPTS:
            logger.error("Máximo de tentativas de reconexão atingido")
            return False
        
        self._reconnect_attempts += 1
        logger.info(f"Tentativa de reconexão {self._reconnect_attempts}/{Config.MAX_RECONNECT_ATTEMPTS}")
        
        await asyncio.sleep(Config.RECONNECT_DELAY)
        return await self.connect()
    
    @property
    def is_connected(self) -> bool:
        """Verifica se está conectado"""
        return self._connected