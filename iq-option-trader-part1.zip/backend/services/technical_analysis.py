"""
Sistema de Análise Técnica Avançada
Implementa indicadores técnicos e análise de padrões de candlestick
"""

import asyncio
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from ..utils.logger import setup_logger
from ..core.config import Config

logger = setup_logger(__name__, Config.LOG_FILE, Config.LOG_LEVEL)


class TechnicalAnalysis:
    """Análise técnica de mercado com indicadores avançados"""
    
    def __init__(self):
        """Inicializa o sistema de análise técnica"""
        self.indicators_cache = {}
        
    async def calculate_rsi(self, prices: List[float], period: int = 14) -> float:
        """
        Calcula o RSI (Relative Strength Index)
        
        Args:
            prices: Lista de preços de fechamento
            period: Período para cálculo (padrão: 14)
            
        Returns:
            Valor do RSI (0-100)
        """
        try:
            if len(prices) < period + 1:
                return 50.0
            
            deltas = np.diff(prices)
            gains = np.where(deltas > 0, deltas, 0)
            losses = np.where(deltas < 0, -deltas, 0)
            
            avg_gain = np.mean(gains[-period:])
            avg_loss = np.mean(losses[-period:])
            
            if avg_loss == 0:
                return 100.0
            
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            
            return float(rsi)
            
        except Exception as e:
            logger.error(f"Erro ao calcular RSI: {str(e)}")
            return 50.0
    
    async def calculate_macd(
        self, 
        prices: List[float], 
        fast: int = 12, 
        slow: int = 26, 
        signal: int = 9
    ) -> Tuple[float, float, float]:
        """
        Calcula o MACD (Moving Average Convergence Divergence)
        
        Args:
            prices: Lista de preços de fechamento
            fast: Período EMA rápida (padrão: 12)
            slow: Período EMA lenta (padrão: 26)
            signal: Período da linha de sinal (padrão: 9)
            
        Returns:
            Tupla (MACD, Signal, Histogram)
        """
        try:
            if len(prices) < slow:
                return 0.0, 0.0, 0.0
            
            prices_array = np.array(prices)
            
            # Calcular EMAs
            ema_fast = self._calculate_ema(prices_array, fast)
            ema_slow = self._calculate_ema(prices_array, slow)
            
            # MACD line
            macd_line = ema_fast - ema_slow
            
            # Signal line
            signal_line = self._calculate_ema(np.array([macd_line]), signal)
            
            # Histogram
            histogram = macd_line - signal_line
            
            return float(macd_line), float(signal_line), float(histogram)
            
        except Exception as e:
            logger.error(f"Erro ao calcular MACD: {str(e)}")
            return 0.0, 0.0, 0.0
    
    async def calculate_bollinger_bands(
        self, 
        prices: List[float], 
        period: int = 20, 
        std_dev: float = 2.0
    ) -> Tuple[float, float, float]:
        """
        Calcula as Bandas de Bollinger
        
        Args:
            prices: Lista de preços de fechamento
            period: Período da média móvel (padrão: 20)
            std_dev: Desvio padrão (padrão: 2.0)
            
        Returns:
            Tupla (Upper Band, Middle Band, Lower Band)
        """
        try:
            if len(prices) < period:
                return 0.0, 0.0, 0.0
            
            prices_array = np.array(prices[-period:])
            
            # Média móvel simples
            middle_band = np.mean(prices_array)
            
            # Desvio padrão
            std = np.std(prices_array)
            
            # Bandas superior e inferior
            upper_band = middle_band + (std_dev * std)
            lower_band = middle_band - (std_dev * std)
            
            return float(upper_band), float(middle_band), float(lower_band)
            
        except Exception as e:
            logger.error(f"Erro ao calcular Bollinger Bands: {str(e)}")
            return 0.0, 0.0, 0.0
    
    async def calculate_moving_averages(
        self, 
        prices: List[float], 
        periods: List[int] = [20, 50, 200]
    ) -> Dict[int, float]:
        """
        Calcula múltiplas médias móveis
        
        Args:
            prices: Lista de preços de fechamento
            periods: Lista de períodos para calcular
            
        Returns:
            Dicionário com médias móveis {período: valor}
        """
        try:
            mas = {}
            prices_array = np.array(prices)
            
            for period in periods:
                if len(prices) >= period:
                    ma = np.mean(prices_array[-period:])
                    mas[period] = float(ma)
                else:
                    mas[period] = 0.0
            
            return mas
            
        except Exception as e:
            logger.error(f"Erro ao calcular médias móveis: {str(e)}")
            return {p: 0.0 for p in periods}
    
    async def analyze_volume(
        self, 
        volumes: List[float], 
        period: int = 20
    ) -> Dict[str, float]:
        """
        Analisa volume de negociação
        
        Args:
            volumes: Lista de volumes
            period: Período para análise
            
        Returns:
            Dicionário com análise de volume
        """
        try:
            if len(volumes) < period:
                return {"avg_volume": 0.0, "volume_ratio": 1.0, "trend": "neutral"}
            
            volumes_array = np.array(volumes)
            
            avg_volume = np.mean(volumes_array[-period:])
            current_volume = volumes_array[-1]
            volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1.0
            
            # Determinar tendência de volume
            trend = "neutral"
            if volume_ratio > 1.5:
                trend = "high"
            elif volume_ratio < 0.5:
                trend = "low"
            
            return {
                "avg_volume": float(avg_volume),
                "current_volume": float(current_volume),
                "volume_ratio": float(volume_ratio),
                "trend": trend
            }
            
        except Exception as e:
            logger.error(f"Erro ao analisar volume: {str(e)}")
            return {"avg_volume": 0.0, "volume_ratio": 1.0, "trend": "neutral"}
    
    async def detect_candlestick_patterns(
        self, 
        candles: List[Dict]
    ) -> List[str]:
        """
        Detecta padrões de candlestick
        
        Args:
            candles: Lista de candles (open, high, low, close)
            
        Returns:
            Lista de padrões detectados
        """
        try:
            patterns = []
            
            if len(candles) < 3:
                return patterns
            
            # Últimos 3 candles
            c1, c2, c3 = candles[-3], candles[-2], candles[-1]
            
            # Doji
            if self._is_doji(c3):
                patterns.append("DOJI")
            
            # Hammer
            if self._is_hammer(c3):
                patterns.append("HAMMER")
            
            # Shooting Star
            if self._is_shooting_star(c3):
                patterns.append("SHOOTING_STAR")
            
            # Engulfing
            if self._is_bullish_engulfing(c2, c3):
                patterns.append("BULLISH_ENGULFING")
            elif self._is_bearish_engulfing(c2, c3):
                patterns.append("BEARISH_ENGULFING")
            
            # Three White Soldiers
            if self._is_three_white_soldiers(c1, c2, c3):
                patterns.append("THREE_WHITE_SOLDIERS")
            
            # Three Black Crows
            if self._is_three_black_crows(c1, c2, c3):
                patterns.append("THREE_BLACK_CROWS")
            
            return patterns
            
        except Exception as e:
            logger.error(f"Erro ao detectar padrões: {str(e)}")
            return []
    
    async def generate_signal(
        self, 
        prices: List[float], 
        volumes: List[float],
        candles: List[Dict]
    ) -> Dict[str, any]:
        """
        Gera sinal de compra/venda baseado em múltiplos indicadores
        
        Args:
            prices: Lista de preços
            volumes: Lista de volumes
            candles: Lista de candles
            
        Returns:
            Dicionário com sinal e análise completa
        """
        try:
            # Calcular indicadores
            rsi = await self.calculate_rsi(prices)
            macd, signal, histogram = await self.calculate_macd(prices)
            upper_bb, middle_bb, lower_bb = await self.calculate_bollinger_bands(prices)
            mas = await self.calculate_moving_averages(prices)
            volume_analysis = await self.analyze_volume(volumes)
            patterns = await self.detect_candlestick_patterns(candles)
            
            current_price = prices[-1]
            
            # Sistema de pontuação
            buy_score = 0
            sell_score = 0
            
            # RSI
            if rsi < 30:
                buy_score += 2
            elif rsi > 70:
                sell_score += 2
            elif rsi < 40:
                buy_score += 1
            elif rsi > 60:
                sell_score += 1
            
            # MACD
            if histogram > 0 and macd > signal:
                buy_score += 2
            elif histogram < 0 and macd < signal:
                sell_score += 2
            
            # Bollinger Bands
            if current_price < lower_bb:
                buy_score += 2
            elif current_price > upper_bb:
                sell_score += 2
            
            # Médias Móveis
            if 20 in mas and 50 in mas:
                if mas[20] > mas[50]:
                    buy_score += 1
                else:
                    sell_score += 1
            
            # Volume
            if volume_analysis["trend"] == "high":
                # Alto volume reforça o sinal
                if buy_score > sell_score:
                    buy_score += 1
                elif sell_score > buy_score:
                    sell_score += 1
            
            # Padrões de candlestick
            bullish_patterns = ["HAMMER", "BULLISH_ENGULFING", "THREE_WHITE_SOLDIERS"]
            bearish_patterns = ["SHOOTING_STAR", "BEARISH_ENGULFING", "THREE_BLACK_CROWS"]
            
            for pattern in patterns:
                if pattern in bullish_patterns:
                    buy_score += 1
                elif pattern in bearish_patterns:
                    sell_score += 1
            
            # Determinar sinal
            signal_type = "HOLD"
            confidence = 0.0
            
            total_score = buy_score + sell_score
            if total_score > 0:
                if buy_score > sell_score:
                    signal_type = "BUY"
                    confidence = (buy_score / total_score) * 100
                elif sell_score > buy_score:
                    signal_type = "SELL"
                    confidence = (sell_score / total_score) * 100
                else:
                    confidence = 50.0
            
            return {
                "signal": signal_type,
                "confidence": round(confidence, 2),
                "indicators": {
                    "rsi": round(rsi, 2),
                    "macd": round(macd, 4),
                    "macd_signal": round(signal, 4),
                    "macd_histogram": round(histogram, 4),
                    "bb_upper": round(upper_bb, 4),
                    "bb_middle": round(middle_bb, 4),
                    "bb_lower": round(lower_bb, 4),
                    "ma_20": round(mas.get(20, 0), 4),
                    "ma_50": round(mas.get(50, 0), 4),
                    "volume_ratio": round(volume_analysis["volume_ratio"], 2)
                },
                "patterns": patterns,
                "scores": {
                    "buy": buy_score,
                    "sell": sell_score
                },
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Erro ao gerar sinal: {str(e)}")
            return {
                "signal": "HOLD",
                "confidence": 0.0,
                "indicators": {},
                "patterns": [],
                "error": str(e)
            }
    
    def _calculate_ema(self, data: np.ndarray, period: int) -> float:
        """Calcula EMA (Exponential Moving Average)"""
        if len(data) < period:
            return np.mean(data)
        
        multiplier = 2 / (period + 1)
        ema = np.mean(data[:period])
        
        for price in data[period:]:
            ema = (price * multiplier) + (ema * (1 - multiplier))
        
        return ema
    
    def _is_doji(self, candle: Dict) -> bool:
        """Detecta padrão Doji"""
        body = abs(candle["close"] - candle["open"])
        range_size = candle["high"] - candle["low"]
        return body < (range_size * 0.1) if range_size > 0 else False
    
    def _is_hammer(self, candle: Dict) -> bool:
        """Detecta padrão Hammer"""
        body = abs(candle["close"] - candle["open"])
        lower_shadow = min(candle["open"], candle["close"]) - candle["low"]
        upper_shadow = candle["high"] - max(candle["open"], candle["close"])
        
        return (lower_shadow > body * 2) and (upper_shadow < body * 0.3)
    
    def _is_shooting_star(self, candle: Dict) -> bool:
        """Detecta padrão Shooting Star"""
        body = abs(candle["close"] - candle["open"])
        upper_shadow = candle["high"] - max(candle["open"], candle["close"])
        lower_shadow = min(candle["open"], candle["close"]) - candle["low"]
        
        return (upper_shadow > body * 2) and (lower_shadow < body * 0.3)
    
    def _is_bullish_engulfing(self, prev: Dict, curr: Dict) -> bool:
        """Detecta padrão Bullish Engulfing"""
        prev_bearish = prev["close"] < prev["open"]
        curr_bullish = curr["close"] > curr["open"]
        
        return (prev_bearish and curr_bullish and 
                curr["close"] > prev["open"] and 
                curr["open"] < prev["close"])
    
    def _is_bearish_engulfing(self, prev: Dict, curr: Dict) -> bool:
        """Detecta padrão Bearish Engulfing"""
        prev_bullish = prev["close"] > prev["open"]
        curr_bearish = curr["close"] < curr["open"]
        
        return (prev_bullish and curr_bearish and 
                curr["close"] < prev["open"] and 
                curr["open"] > prev["close"])
    
    def _is_three_white_soldiers(self, c1: Dict, c2: Dict, c3: Dict) -> bool:
        """Detecta padrão Three White Soldiers"""
        return (c1["close"] > c1["open"] and 
                c2["close"] > c2["open"] and 
                c3["close"] > c3["open"] and
                c2["close"] > c1["close"] and 
                c3["close"] > c2["close"])
    
    def _is_three_black_crows(self, c1: Dict, c2: Dict, c3: Dict) -> bool:
        """Detecta padrão Three Black Crows"""
        return (c1["close"] < c1["open"] and 
                c2["close"] < c2["open"] and 
                c3["close"] < c3["open"] and
                c2["close"] < c1["close"] and 
                c3["close"] < c2["close"])