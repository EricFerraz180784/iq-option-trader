"""
Servidor WebSocket para comunicação em tempo real
Transmite atualizações de estado para clientes conectados
"""

import asyncio
import json
from typing import Set
import websockets
from websockets.server import WebSocketServerProtocol
from ..utils.logger import setup_logger
from ..core.config import Config
from ..core.state_manager import StateManager

logger = setup_logger(__name__, Config.LOG_FILE, Config.LOG_LEVEL)

class WebSocketServer:
    """Servidor WebSocket para comunicação em tempo real"""
    
    def __init__(self, state_manager: StateManager, host: str = "0.0.0.0", port: int = 8765):
        """
        Inicializa servidor WebSocket
        
        Args:
            state_manager: Gerenciador de estado
            host: Host do servidor
            port: Porta do servidor
        """
        self.state_manager = state_manager
        self.host = host
        self.port = port
        self.clients: Set[WebSocketServerProtocol] = set()
        self._server = None
    
    async def register(self, websocket: WebSocketServerProtocol) -> None:
        """Registra novo cliente"""
        self.clients.add(websocket)
        logger.info(f"Cliente conectado. Total: {len(self.clients)}")
        
        # Enviar estado atual para novo cliente
        state = await self.state_manager.get_state()
        await websocket.send(json.dumps(state.to_dict()))
    
    async def unregister(self, websocket: WebSocketServerProtocol) -> None:
        """Remove cliente"""
        self.clients.discard(websocket)
        logger.info(f"Cliente desconectado. Total: {len(self.clients)}")
    
    async def broadcast(self, message: dict) -> None:
        """
        Envia mensagem para todos os clientes
        
        Args:
            message: Mensagem para broadcast
        """
        if not self.clients:
            return
        
        message_json = json.dumps(message)
        
        # Enviar para todos os clientes conectados
        disconnected = set()
        for websocket in self.clients:
            try:
                await websocket.send(message_json)
            except websockets.exceptions.ConnectionClosed:
                disconnected.add(websocket)
            except Exception as e:
                logger.error(f"Erro ao enviar mensagem: {str(e)}")
                disconnected.add(websocket)
        
        # Remover clientes desconectados
        for websocket in disconnected:
            await self.unregister(websocket)
    
    async def handle_client(self, websocket: WebSocketServerProtocol, path: str) -> None:
        """
        Gerencia conexão de cliente
        
        Args:
            websocket: Conexão WebSocket
            path: Path da requisição
        """
        await self.register(websocket)
        
        try:
            async for message in websocket:
                # Processar mensagens do cliente se necessário
                try:
                    data = json.loads(message)
                    logger.debug(f"Mensagem recebida: {data}")
                    
                    # Aqui você pode adicionar lógica para processar comandos do cliente
                    # Por exemplo: pausar/resumir trading, alterar configurações, etc.
                    
                except json.JSONDecodeError:
                    logger.warning(f"Mensagem inválida recebida: {message}")
                    
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            await self.unregister(websocket)
    
    async def start(self) -> None:
        """Inicia servidor WebSocket"""
        try:
            self._server = await websockets.serve(
                self.handle_client,
                self.host,
                self.port
            )
            logger.info(f"✓ Servidor WebSocket iniciado em ws://{self.host}:{self.port}")
            
            # Registrar callback para broadcast de mudanças de estado
            async def on_state_change(state: dict):
                await self.broadcast(state)
            
            self.state_manager.subscribe(on_state_change)
            
        except Exception as e:
            logger.error(f"✗ Erro ao iniciar servidor WebSocket: {str(e)}")
            raise
    
    async def stop(self) -> None:
        """Para servidor WebSocket"""
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            logger.info("Servidor WebSocket parado")
    
    @property
    def is_running(self) -> bool:
        """Verifica se está rodando"""
        return self._server is not None