"""
Serviço de captura de tela
Captura e processa screenshots do sistema
"""

import asyncio
import base64
import io
from typing import Optional
from PIL import Image
import mss
from ..utils.logger import setup_logger
from ..core.config import Config

logger = setup_logger(__name__, Config.LOG_FILE, Config.LOG_LEVEL)

class ScreenCaptureService:
    """Serviço de captura de tela"""
    
    def __init__(self, quality: int = 40, monitor_index: int = 1):
        """
        Inicializa serviço de captura
        
        Args:
            quality: Qualidade JPEG (1-100)
            monitor_index: Índice do monitor a capturar
        """
        self.quality = quality
        self.monitor_index = monitor_index
        self._sct: Optional[mss.mss] = None
        self._running = False
    
    async def start(self) -> None:
        """Inicia serviço de captura"""
        try:
            loop = asyncio.get_event_loop()
            self._sct = await loop.run_in_executor(None, mss.mss)
            self._running = True
            logger.info("✓ Serviço de captura de tela iniciado")
        except Exception as e:
            logger.error(f"✗ Erro ao iniciar captura de tela: {str(e)}")
            self._running = False
    
    async def stop(self) -> None:
        """Para serviço de captura"""
        self._running = False
        if self._sct:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self._sct.close)
            self._sct = None
        logger.info("Serviço de captura de tela parado")
    
    async def capture(self) -> str:
        """
        Captura tela e retorna como base64
        
        Returns:
            String base64 da imagem JPEG
        """
        if not self._running or not self._sct:
            return ""
        
        try:
            loop = asyncio.get_event_loop()
            
            # Capturar tela
            monitors = self._sct.monitors
            if self.monitor_index >= len(monitors):
                self.monitor_index = 1
            
            monitor = monitors[self.monitor_index]
            sct_img = await loop.run_in_executor(
                None,
                lambda: self._sct.grab(monitor)
            )
            
            # Converter para PIL Image
            img = Image.frombytes(
                "RGB",
                sct_img.size,
                sct_img.bgra,
                "raw",
                "BGRX"
            )
            
            # Redimensionar para economizar banda
            img.thumbnail((1280, 720), Image.Resampling.LANCZOS)
            
            # Converter para JPEG em memória
            buf = io.BytesIO()
            await loop.run_in_executor(
                None,
                lambda: img.save(buf, format="JPEG", quality=self.quality, optimize=True)
            )
            
            # Retornar como base64
            img_base64 = base64.b64encode(buf.getvalue()).decode("utf-8")
            return img_base64
            
        except Exception as e:
            logger.error(f"Erro ao capturar tela: {str(e)}")
            return ""
    
    @property
    def is_running(self) -> bool:
        """Verifica se está rodando"""
        return self._running