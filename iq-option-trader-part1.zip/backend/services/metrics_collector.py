"""
Coletor de métricas do sistema
Monitora CPU, RAM, latência e outras métricas
"""

import asyncio
import psutil
import time
from typing import Dict
from ..utils.logger import setup_logger
from ..core.config import Config

logger = setup_logger(__name__, Config.LOG_FILE, Config.LOG_LEVEL)

class MetricsCollector:
    """Coletor de métricas do sistema"""
    
    def __init__(self):
        self._last_ping_time = 0
        self._ping_history = []
    
    async def get_cpu_usage(self) -> str:
        """
        Obtém uso de CPU
        
        Returns:
            String formatada com percentual de CPU
        """
        try:
            loop = asyncio.get_event_loop()
            cpu_percent = await loop.run_in_executor(
                None,
                lambda: psutil.cpu_percent(interval=0.1)
            )
            return f"{cpu_percent:.1f}%"
        except Exception as e:
            logger.error(f"Erro ao obter CPU: {str(e)}")
            return "0%"
    
    async def get_ram_usage(self) -> str:
        """
        Obtém uso de RAM
        
        Returns:
            String formatada com percentual de RAM
        """
        try:
            loop = asyncio.get_event_loop()
            memory = await loop.run_in_executor(
                None,
                psutil.virtual_memory
            )
            return f"{memory.percent:.1f}%"
        except Exception as e:
            logger.error(f"Erro ao obter RAM: {str(e)}")
            return "0%"
    
    async def measure_ping(self, host: str = "8.8.8.8") -> str:
        """
        Mede latência de rede
        
        Args:
            host: Host para ping
        
        Returns:
            String formatada com latência em ms
        """
        try:
            start = time.time()
            
            # Simular ping usando tempo de resposta
            # Em produção, usar biblioteca como 'ping3'
            await asyncio.sleep(0.01)  # Simular latência
            
            elapsed = (time.time() - start) * 1000
            self._ping_history.append(elapsed)
            
            # Manter apenas últimos 10 valores
            if len(self._ping_history) > 10:
                self._ping_history.pop(0)
            
            avg_ping = sum(self._ping_history) / len(self._ping_history)
            return f"{int(avg_ping)}ms"
            
        except Exception as e:
            logger.error(f"Erro ao medir ping: {str(e)}")
            return "0ms"
    
    async def get_all_metrics(self) -> Dict[str, str]:
        """
        Coleta todas as métricas
        
        Returns:
            Dicionário com todas as métricas
        """
        cpu, ram, ping = await asyncio.gather(
            self.get_cpu_usage(),
            self.get_ram_usage(),
            self.measure_ping()
        )
        
        return {
            "cpu": cpu,
            "ram": ram,
            "ping": ping
        }