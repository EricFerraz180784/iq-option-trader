"""
Gerenciador de estado do sistema
Mantém e sincroniza o estado global de forma thread-safe
"""

import asyncio
from typing import Dict, Any, List, Callable
from datetime import datetime
from dataclasses import dataclass, field, asdict

@dataclass
class SystemState:
    """Estado do sistema"""
    saldo: float = 0.0
    lucro: float = 0.0
    uptime: int = 0
    status: str = "BOOTING CORE..."
    ping: str = "0ms"
    cpu: str = "0%"
    ram: str = "0%"
    ops: int = 0
    terminal: List[str] = field(default_factory=list)
    img: str = ""
    last_update: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return asdict(self)

class StateManager:
    """Gerenciador de estado thread-safe"""
    
    def __init__(self, max_terminal_logs: int = 50):
        self._state = SystemState()
        self._lock = asyncio.Lock()
        self._subscribers: List[Callable] = []
        self._max_terminal_logs = max_terminal_logs
        self._start_time = datetime.now()
    
    async def get_state(self) -> SystemState:
        """Retorna cópia do estado atual"""
        async with self._lock:
            return SystemState(**self._state.to_dict())
    
    async def update_state(self, **kwargs) -> None:
        """Atualiza estado e notifica subscribers"""
        async with self._lock:
            # Atualizar campos
            for key, value in kwargs.items():
                if hasattr(self._state, key):
                    if key == "terminal" and isinstance(value, list):
                        # Adicionar novas mensagens ao terminal
                        self._state.terminal = (value + self._state.terminal)[:self._max_terminal_logs]
                    else:
                        setattr(self._state, key, value)
            
            # Atualizar uptime
            self._state.uptime = int((datetime.now() - self._start_time).total_seconds())
            self._state.last_update = datetime.now().isoformat()
            
            # Notificar subscribers
            await self._notify_subscribers()
    
    async def add_terminal_log(self, message: str) -> None:
        """Adiciona mensagem ao terminal"""
        await self.update_state(terminal=[message])
    
    def subscribe(self, callback: Callable) -> None:
        """Registra callback para mudanças de estado"""
        if callback not in self._subscribers:
            self._subscribers.append(callback)
    
    def unsubscribe(self, callback: Callable) -> None:
        """Remove callback"""
        if callback in self._subscribers:
            self._subscribers.remove(callback)
    
    async def _notify_subscribers(self) -> None:
        """Notifica todos os subscribers sobre mudança de estado"""
        state_dict = self._state.to_dict()
        for callback in self._subscribers:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(state_dict)
                else:
                    callback(state_dict)
            except Exception as e:
                print(f"Erro ao notificar subscriber: {e}")
    
    async def set_status(self, status: str) -> None:
        """Define status do sistema"""
        await self.update_state(status=status)
    
    async def increment_ops(self) -> None:
        """Incrementa contador de operações"""
        async with self._lock:
            self._state.ops += 1
        await self._notify_subscribers()