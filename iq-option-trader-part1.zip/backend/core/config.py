"""
Gerenciamento centralizado de configurações
Carrega variáveis de ambiente e define configurações do sistema
"""

import os
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

class Config:
    """Classe de configuração centralizada"""
    
    # Paths
    BASE_DIR = Path(__file__).parent.parent
    LOGS_DIR = BASE_DIR / "logs"
    DATA_DIR = BASE_DIR / "data"
    
    # IQ Option
    IQ_OPTION_EMAIL: str = os.getenv("IQ_OPTION_EMAIL", "")
    IQ_OPTION_PASSWORD: str = os.getenv("IQ_OPTION_PASSWORD", "")
    BALANCE_TYPE: str = os.getenv("BALANCE_TYPE", "PRACTICE")
    
    # Server
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8765"))
    WEB_PORT: int = int(os.getenv("WEB_PORT", "8081"))
    
    # Environment
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    DEBUG: bool = os.getenv("DEBUG", "False").lower() == "true"
    
    # Logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE: str = os.getenv("LOG_FILE", "logs/vfss.log")
    
    # Security
    SECRET_KEY: str = os.getenv("SECRET_KEY", "default-secret-key-change-in-production")
    ENCRYPTION_KEY: Optional[str] = os.getenv("ENCRYPTION_KEY")
    
    # Trading
    AUTO_RECONNECT: bool = os.getenv("AUTO_RECONNECT", "True").lower() == "true"
    MAX_RECONNECT_ATTEMPTS: int = int(os.getenv("MAX_RECONNECT_ATTEMPTS", "5"))
    RECONNECT_DELAY: int = int(os.getenv("RECONNECT_DELAY", "3"))
    
    # Performance
    SCREEN_CAPTURE_INTERVAL: int = int(os.getenv("SCREEN_CAPTURE_INTERVAL", "2"))
    DATA_UPDATE_INTERVAL: int = int(os.getenv("DATA_UPDATE_INTERVAL", "1"))
    MAX_TERMINAL_LOGS: int = int(os.getenv("MAX_TERMINAL_LOGS", "50"))
    
    @classmethod
    def validate(cls) -> bool:
        """Valida configurações críticas"""
        if not cls.IQ_OPTION_EMAIL or not cls.IQ_OPTION_PASSWORD:
            return False
        return True
    
    @classmethod
    def create_directories(cls) -> None:
        """Cria diretórios necessários"""
        cls.LOGS_DIR.mkdir(exist_ok=True)
        cls.DATA_DIR.mkdir(exist_ok=True)

# Criar diretórios ao importar
Config.create_directories()