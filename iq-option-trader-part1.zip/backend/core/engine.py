"""
Motor principal do sistema VFSS
Coordena todos os serviços e gerencia o ciclo de vida do sistema
"""

import asyncio
import signal
from typing import Optional
from ..utils.logger import setup_logger
from ..core.config import Config
from ..core.state_manager import StateManager
from ..services.iq_option_service import IQOptionService
from ..services.screen_capture import ScreenCaptureService
from ..services.metrics_collector import MetricsCollector
from ..services.websocket_server import WebSocketServer

logger = setup_logger(__name__, Config.LOG_FILE, Config.LOG_LEVEL)

class VFSSEngine:
    """Motor principal do sistema VFSS Quantum Core"""
    
    def __init__(self):
        """Inicializa o motor"""
        self.state_manager = StateManager(max_terminal_logs=Config.MAX_TERMINAL_LOGS)
        self.iq_service: Optional[IQOptionService] = None
        self.screen_service: Optional[ScreenCaptureService] = None
        self.metrics_collector = MetricsCollector()
        self.websocket_server: Optional[WebSocketServer] = None
        self._running = False
        self._tasks = []
    
    async def initialize(self) -> bool:
        """
        Inicializa todos os serviços
        
        Returns:
            True se inicializado com sucesso
        """
        try:
            logger.info("=" * 60)
            logger.info("VFSS QUANTUM CORE v3.0.0 - Inicializando...")
            logger.info("=" * 60)
            
            await self.state_manager.add_terminal_log("Iniciando protocolo VFSS Quantum Core...")
            await self.state_manager.set_status("INICIALIZANDO...")
            
            # Validar configurações
            if not Config.validate():
                logger.error("✗ Configurações inválidas. Verifique credenciais no arquivo .env")
                await self.state_manager.set_status("ERRO CONFIGURAÇÃO")
                return False
            
            await self.state_manager.add_terminal_log("Verificando módulos de IA...")
            
            # Inicializar IQ Option Service
            if Config.IQ_OPTION_EMAIL and Config.IQ_OPTION_PASSWORD:
                self.iq_service = IQOptionService(
                    Config.IQ_OPTION_EMAIL,
                    Config.IQ_OPTION_PASSWORD
                )
                
                await self.state_manager.add_terminal_log("Estabelecendo conexão segura SSL/TLS...")
                connected = await self.iq_service.connect()
                
                if not connected:
                    logger.warning("Falha ao conectar com IQ Option. Continuando em modo demo...")
                    await self.state_manager.add_terminal_log("⚠ Modo demonstração ativado")
            
            # Inicializar Screen Capture Service
            await self.state_manager.add_terminal_log("Carregando módulo de captura visual...")
            self.screen_service = ScreenCaptureService()
            await self.screen_service.start()
            
            # Inicializar WebSocket Server
            await self.state_manager.add_terminal_log("Iniciando servidor de comunicação em tempo real...")
            self.websocket_server = WebSocketServer(
                self.state_manager,
                Config.HOST,
                Config.PORT
            )
            await self.websocket_server.start()
            
            await self.state_manager.set_status("NÚCLEO ONLINE")
            await self.state_manager.add_terminal_log("✓ Sistema operacional - Aguardando sinais de mercado...")
            
            logger.info("✓ Sistema inicializado com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"✗ Erro na inicialização: {str(e)}")
            await self.state_manager.set_status("ERRO CRÍTICO")
            return False
    
    async def run(self) -> None:
        """Loop principal do sistema"""
        self._running = True
        
        # Criar tasks para execução paralela
        self._tasks = [
            asyncio.create_task(self._update_trading_data()),
            asyncio.create_task(self._update_metrics()),
            asyncio.create_task(self._update_screen_capture()),
            asyncio.create_task(self._monitor_connection())
        ]
        
        logger.info("Motor principal em execução...")
        
        try:
            # Aguardar todas as tasks
            await asyncio.gather(*self._tasks)
        except asyncio.CancelledError:
            logger.info("Tasks canceladas")
    
    async def _update_trading_data(self) -> None:
        """Atualiza dados de trading"""
        while self._running:
            try:
                if self.iq_service and self.iq_service.is_connected:
                    # Obter saldo
                    saldo = await self.iq_service.get_balance()
                    
                    # Calcular lucro (simulado - implementar lógica real)
                    lucro = saldo - 10000.0  # Assumindo saldo inicial de 10000
                    
                    await self.state_manager.update_state(
                        saldo=saldo,
                        lucro=lucro
                    )
                    
                    # Simular detecção de padrões ocasionalmente
                    import random
                    if random.random() > 0.95:
                        await self.state_manager.increment_ops()
                        await self.state_manager.add_terminal_log(
                            "Padrão de vela detectado - Analisando indicadores técnicos..."
                        )
                
                await asyncio.sleep(Config.DATA_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Erro ao atualizar dados de trading: {str(e)}")
                await asyncio.sleep(5)
    
    async def _update_metrics(self) -> None:
        """Atualiza métricas do sistema"""
        while self._running:
            try:
                metrics = await self.metrics_collector.get_all_metrics()
                await self.state_manager.update_state(**metrics)
                await asyncio.sleep(Config.DATA_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Erro ao atualizar métricas: {str(e)}")
                await asyncio.sleep(5)
    
    async def _update_screen_capture(self) -> None:
        """Atualiza captura de tela"""
        while self._running:
            try:
                if self.screen_service and self.screen_service.is_running:
                    img_base64 = await self.screen_service.capture()
                    if img_base64:
                        await self.state_manager.update_state(img=img_base64)
                
                await asyncio.sleep(Config.SCREEN_CAPTURE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Erro ao capturar tela: {str(e)}")
                await asyncio.sleep(5)
    
    async def _monitor_connection(self) -> None:
        """Monitora conexão e tenta reconectar se necessário"""
        while self._running:
            try:
                if self.iq_service:
                    is_connected = await self.iq_service.check_connection()
                    
                    if not is_connected:
                        logger.warning("Conexão perdida. Tentando reconectar...")
                        await self.state_manager.set_status("RECONECTANDO...")
                        await self.state_manager.add_terminal_log("⚠ Conexão perdida - Iniciando protocolo de reconexão...")
                        
                        reconnected = await self.iq_service.auto_reconnect()
                        
                        if reconnected:
                            await self.state_manager.set_status("NÚCLEO ONLINE")
                            await self.state_manager.add_terminal_log("✓ Reconexão bem-sucedida")
                        else:
                            await self.state_manager.set_status("ERRO CONEXÃO")
                
                await asyncio.sleep(10)
                
            except Exception as e:
                logger.error(f"Erro ao monitorar conexão: {str(e)}")
                await asyncio.sleep(10)
    
    async def shutdown(self) -> None:
        """Desliga o sistema gracefully"""
        logger.info("Iniciando desligamento do sistema...")
        self._running = False
        
        await self.state_manager.set_status("DESLIGANDO...")
        await self.state_manager.add_terminal_log("Iniciando protocolo de desligamento seguro...")
        
        # Cancelar todas as tasks
        for task in self._tasks:
            task.cancel()
        
        # Aguardar cancelamento
        await asyncio.gather(*self._tasks, return_exceptions=True)
        
        # Desligar serviços
        if self.iq_service:
            await self.iq_service.disconnect()
        
        if self.screen_service:
            await self.screen_service.stop()
        
        if self.websocket_server:
            await self.websocket_server.stop()
        
        logger.info("✓ Sistema desligado com sucesso")

async def main():
    """Função principal"""
    engine = VFSSEngine()
    
    # Configurar handlers de sinal para desligamento graceful
    loop = asyncio.get_event_loop()
    
    def signal_handler():
        logger.info("Sinal de interrupção recebido")
        asyncio.create_task(engine.shutdown())
    
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, signal_handler)
    
    # Inicializar e executar
    if await engine.initialize():
        try:
            await engine.run()
        except KeyboardInterrupt:
            pass
        finally:
            await engine.shutdown()
    else:
        logger.error("Falha na inicialização. Sistema não pode ser iniciado.")
        return 1
    
    return 0

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)