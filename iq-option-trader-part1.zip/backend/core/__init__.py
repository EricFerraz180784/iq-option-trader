"""
VFSS Quantum Core - Sistema de Trading de Última Geração
Módulo principal do núcleo do sistema
"""

__version__ = "3.0.0"
__author__ = "VFSS Team"