"""
Motor principal do sistema VFSS - Versão Atualizada
Integra análise técnica, auto-trading, IA e backtesting
"""

import asyncio
import signal
from typing import Optional
from ..utils.logger import setup_logger
from ..core.config import Config
from ..core.state_manager import StateManager
from ..services.iq_option_service import IQOptionService
from ..services.screen_capture import ScreenCaptureService
from ..services.metrics_collector import MetricsCollector
from ..services.websocket_server import WebSocketServer
from ..services.technical_analysis import TechnicalAnalysis
from ..services.risk_manager import RiskManager
from ..services.auto_trader import AutoTrader
from ..services.ai_predictor import AIPredictor
from ..services.backtester import Backtester

logger = setup_logger(__name__, Config.LOG_FILE, Config.LOG_LEVEL)


class VFSSEngine:
    """Motor principal do sistema VFSS Quantum Core com Auto-Trading"""
    
    def __init__(self):
        """Inicializa o motor"""
        self.state_manager = StateManager(max_terminal_logs=Config.MAX_TERMINAL_LOGS)
        self.iq_service: Optional[IQOptionService] = None
        self.screen_service: Optional[ScreenCaptureService] = None
        self.metrics_collector = MetricsCollector()
        self.websocket_server: Optional[WebSocketServer] = None
        
        # Novos serviços
        self.technical_analysis = TechnicalAnalysis()
        self.risk_manager = RiskManager()
        self.auto_trader: Optional[AutoTrader] = None
        self.ai_predictor = AIPredictor()
        self.backtester = Backtester()
        
        self._running = False
        self._tasks = []
    
    async def initialize(self) -> bool:
        """
        Inicializa todos os serviços
        
        Returns:
            True se inicializado com sucesso
        """
        try:
            logger.info("=" * 60)
            logger.info("VFSS QUANTUM CORE v4.0.0 - Inicializando...")
            logger.info("=" * 60)
            
            await self.state_manager.add_terminal_log("Iniciando protocolo VFSS Quantum Core...")
            await self.state_manager.set_status("INICIALIZANDO...")
            
            # Validar configurações
            if not Config.validate():
                logger.error("✗ Configurações inválidas. Verifique credenciais no arquivo .env")
                await self.state_manager.set_status("ERRO CONFIGURAÇÃO")
                return False
            
            await self.state_manager.add_terminal_log("Verificando módulos de IA...")
            
            # Inicializar IQ Option Service
            if Config.IQ_OPTION_EMAIL and Config.IQ_OPTION_PASSWORD:
                self.iq_service = IQOptionService(
                    Config.IQ_OPTION_EMAIL,
                    Config.IQ_OPTION_PASSWORD
                )
                
                await self.state_manager.add_terminal_log("Estabelecendo conexão segura SSL/TLS...")
                connected = await self.iq_service.connect()
                
                if connected:
                    # Inicializar Auto Trader
                    self.auto_trader = AutoTrader(
                        self.iq_service,
                        self.technical_analysis,
                        self.risk_manager
                    )
                    await self.state_manager.add_terminal_log("✓ Sistema de Auto-Trading inicializado")
                else:
                    logger.warning("Falha ao conectar com IQ Option. Continuando em modo demo...")
                    await self.state_manager.add_terminal_log("⚠ Modo demonstração ativado")
            
            # Inicializar Screen Capture Service
            await self.state_manager.add_terminal_log("Carregando módulo de captura visual...")
            self.screen_service = ScreenCaptureService()
            await self.screen_service.start()
            
            # Inicializar WebSocket Server
            await self.state_manager.add_terminal_log("Iniciando servidor de comunicação em tempo real...")
            self.websocket_server = WebSocketServer(
                self.state_manager,
                Config.HOST,
                Config.PORT
            )
            
            # Registrar handlers de comandos
            self._register_command_handlers()
            
            await self.websocket_server.start()
            
            await self.state_manager.set_status("NÚCLEO ONLINE")
            await self.state_manager.add_terminal_log("✓ Sistema operacional - Aguardando sinais de mercado...")
            
            logger.info("✓ Sistema inicializado com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"✗ Erro na inicialização: {str(e)}")
            await self.state_manager.set_status("ERRO CRÍTICO")
            return False
    
    def _register_command_handlers(self):
        """Registra handlers para comandos do WebSocket"""
        if not self.websocket_server:
            return
        
        # Comandos do Auto Trader
        self.websocket_server.register_command("start_robot", self._handle_start_robot)
        self.websocket_server.register_command("stop_robot", self._handle_stop_robot)
        self.websocket_server.register_command("get_robot_status", self._handle_get_robot_status)
        self.websocket_server.register_command("update_robot_config", self._handle_update_robot_config)
        
        # Comandos de análise
        self.websocket_server.register_command("analyze_asset", self._handle_analyze_asset)
        self.websocket_server.register_command("get_signals", self._handle_get_signals)
        
        # Comandos de backtesting
        self.websocket_server.register_command("run_backtest", self._handle_run_backtest)
        
        # Comandos de IA
        self.websocket_server.register_command("train_ai", self._handle_train_ai)
        self.websocket_server.register_command("ai_predict", self._handle_ai_predict)
    
    async def _handle_start_robot(self, data: dict) -> dict:
        """Handler para iniciar o robô"""
        if not self.auto_trader:
            return {"success": False, "error": "Auto Trader não disponível"}
        
        mode = data.get("mode", "SIMULATION")
        success = await self.auto_trader.start(mode)
        
        if success:
            await self.state_manager.add_terminal_log(f"🤖 Robô iniciado em modo {mode}")
        
        return {"success": success, "mode": mode}
    
    async def _handle_stop_robot(self, data: dict) -> dict:
        """Handler para parar o robô"""
        if not self.auto_trader:
            return {"success": False, "error": "Auto Trader não disponível"}
        
        await self.auto_trader.stop()
        await self.state_manager.add_terminal_log("🤖 Robô parado")
        
        return {"success": True}
    
    async def _handle_get_robot_status(self, data: dict) -> dict:
        """Handler para obter status do robô"""
        if not self.auto_trader:
            return {"success": False, "error": "Auto Trader não disponível"}
        
        status = await self.auto_trader.get_status()
        return {"success": True, "status": status}
    
    async def _handle_update_robot_config(self, data: dict) -> dict:
        """Handler para atualizar configurações do robô"""
        if not self.auto_trader:
            return {"success": False, "error": "Auto Trader não disponível"}
        
        config = data.get("config", {})
        success = await self.auto_trader.update_config(config)
        
        return {"success": success}
    
    async def _handle_analyze_asset(self, data: dict) -> dict:
        """Handler para analisar um ativo"""
        if not self.auto_trader:
            return {"success": False, "error": "Auto Trader não disponível"}
        
        asset = data.get("asset", "EURUSD")
        result = await self.auto_trader.analyze_and_trade(asset)
        
        return {"success": True, "analysis": result}
    
    async def _handle_get_signals(self, data: dict) -> dict:
        """Handler para obter sinais atuais"""
        if not self.auto_trader:
            return {"success": False, "error": "Auto Trader não disponível"}
        
        status = await self.auto_trader.get_status()
        return {"success": True, "signals": status.get("last_signals", {})}
    
    async def _handle_run_backtest(self, data: dict) -> dict:
        """Handler para executar backtest"""
        if not self.iq_service:
            return {"success": False, "error": "IQ Option não conectado"}
        
        asset = data.get("asset", "EURUSD")
        periods = data.get("periods", 1000)
        
        result = await self.backtester.run_backtest(
            self.iq_service,
            self.technical_analysis,
            self.risk_manager,
            asset,
            periods=periods
        )
        
        return {"success": True, "backtest": result}
    
    async def _handle_train_ai(self, data: dict) -> dict:
        """Handler para treinar IA"""
        if not self.iq_service:
            return {"success": False, "error": "IQ Option não conectado"}
        
        assets = data.get("assets", ["EURUSD", "GBPUSD"])
        
        await self.state_manager.add_terminal_log("🧠 Iniciando treinamento de IA...")
        
        training_data = await self.ai_predictor.generate_training_data(
            self.iq_service,
            self.technical_analysis,
            assets
        )
        
        success = await self.ai_predictor.train(training_data)
        
        if success:
            await self.state_manager.add_terminal_log("✓ IA treinada com sucesso")
        
        return {"success": success, "samples": len(training_data)}
    
    async def _handle_ai_predict(self, data: dict) -> dict:
        """Handler para previsão de IA"""
        asset = data.get("asset", "EURUSD")
        
        if not self.iq_service:
            return {"success": False, "error": "IQ Option não conectado"}
        
        # Obter dados
        candles = await self.iq_service.get_candles(asset, 60, 200)
        prices = [c["close"] for c in candles]
        volumes = [c.get("volume", 1000) for c in candles]
        
        # Análise técnica
        signal_data = await self.technical_analysis.generate_signal(prices, volumes, candles)
        
        # Previsão IA
        prediction = await self.ai_predictor.predict(prices, volumes, signal_data["indicators"])
        
        return {"success": True, "prediction": prediction}
    
    async def run(self) -> None:
        """Loop principal do sistema"""
        self._running = True
        
        # Criar tasks para execução paralela
        self._tasks = [
            asyncio.create_task(self._update_trading_data()),
            asyncio.create_task(self._update_metrics()),
            asyncio.create_task(self._update_screen_capture()),
            asyncio.create_task(self._monitor_connection()),
            asyncio.create_task(self._run_auto_trader())
        ]
        
        logger.info("Motor principal em execução...")
        
        try:
            await asyncio.gather(*self._tasks)
        except asyncio.CancelledError:
            logger.info("Tasks canceladas")
    
    async def _run_auto_trader(self) -> None:
        """Executa o auto trader em loop"""
        while self._running:
            try:
                if self.auto_trader and self.auto_trader.is_running:
                    # Analisar cada ativo ativo
                    for asset in self.auto_trader.active_assets:
                        await self.auto_trader.analyze_and_trade(asset)
                    
                    # Monitorar posições abertas
                    await self.auto_trader.monitor_positions()
                    
                    # Atualizar estatísticas
                    stats = await self.risk_manager.get_statistics()
                    await self.state_manager.update_state(
                        robot_stats=stats
                    )
                
                await asyncio.sleep(5)  # Verificar a cada 5 segundos
                
            except Exception as e:
                logger.error(f"Erro no auto trader: {str(e)}")
                await asyncio.sleep(10)
    
    async def _update_trading_data(self) -> None:
        """Atualiza dados de trading"""
        while self._running:
            try:
                if self.iq_service and self.iq_service.is_connected:
                    saldo = await self.iq_service.get_balance()
                    lucro = saldo - 10000.0
                    
                    await self.state_manager.update_state(
                        saldo=saldo,
                        lucro=lucro
                    )
                
                await asyncio.sleep(Config.DATA_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Erro ao atualizar dados de trading: {str(e)}")
                await asyncio.sleep(5)
    
    async def _update_metrics(self) -> None:
        """Atualiza métricas do sistema"""
        while self._running:
            try:
                metrics = await self.metrics_collector.get_all_metrics()
                await self.state_manager.update_state(**metrics)
                await asyncio.sleep(Config.DATA_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Erro ao atualizar métricas: {str(e)}")
                await asyncio.sleep(5)
    
    async def _update_screen_capture(self) -> None:
        """Atualiza captura de tela"""
        while self._running:
            try:
                if self.screen_service and self.screen_service.is_running:
                    img_base64 = await self.screen_service.capture()
                    if img_base64:
                        await self.state_manager.update_state(img=img_base64)
                
                await asyncio.sleep(Config.SCREEN_CAPTURE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Erro ao capturar tela: {str(e)}")
                await asyncio.sleep(5)
    
    async def _monitor_connection(self) -> None:
        """Monitora conexão e tenta reconectar se necessário"""
        while self._running:
            try:
                if self.iq_service:
                    is_connected = await self.iq_service.check_connection()
                    
                    if not is_connected:
                        logger.warning("Conexão perdida. Tentando reconectar...")
                        await self.state_manager.set_status("RECONECTANDO...")
                        
                        reconnected = await self.iq_service.auto_reconnect()
                        
                        if reconnected:
                            await self.state_manager.set_status("NÚCLEO ONLINE")
                        else:
                            await self.state_manager.set_status("ERRO CONEXÃO")
                
                await asyncio.sleep(10)
                
            except Exception as e:
                logger.error(f"Erro ao monitorar conexão: {str(e)}")
                await asyncio.sleep(10)
    
    async def shutdown(self) -> None:
        """Desliga o sistema gracefully"""
        logger.info("Iniciando desligamento do sistema...")
        self._running = False
        
        await self.state_manager.set_status("DESLIGANDO...")
        
        # Parar auto trader
        if self.auto_trader:
            await self.auto_trader.stop()
        
        # Cancelar todas as tasks
        for task in self._tasks:
            task.cancel()
        
        await asyncio.gather(*self._tasks, return_exceptions=True)
        
        # Desligar serviços
        if self.iq_service:
            await self.iq_service.disconnect()
        
        if self.screen_service:
            await self.screen_service.stop()
        
        if self.websocket_server:
            await self.websocket_server.stop()
        
        logger.info("✓ Sistema desligado com sucesso")