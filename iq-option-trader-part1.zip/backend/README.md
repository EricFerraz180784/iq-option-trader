# VFSS Quantum Core v3.0.0 - Backend

Sistema de Trading de Última Geração com arquitetura moderna e tecnologias de ponta.

## 🚀 Características

### Arquitetura
- **Modular**: Separação clara de responsabilidades
- **Assíncrono**: Uso extensivo de async/await para operações não-bloqueantes
- **Escalável**: Preparado para crescimento e múltiplas instâncias
- **Robusto**: Tratamento avançado de erros e reconexão automática

### Tecnologias
- **Python 3.8+**: Linguagem moderna e eficiente
- **AsyncIO**: Programação assíncrona nativa
- **WebSocket**: Comunicação em tempo real
- **FastAPI**: Framework web de alta performance (opcional)
- **Cryptography**: Segurança e criptografia de dados
- **Psutil**: Monitoramento de sistema

### Funcionalidades
- ✅ Conexão segura com IQ Option
- ✅ WebSocket server para comunicação em tempo real
- ✅ Captura de tela otimizada
- ✅ Monitoramento de métricas (CPU, RAM, Latência)
- ✅ Sistema de logging avançado com rotação
- ✅ Reconexão automática
- ✅ Gerenciamento de estado thread-safe
- ✅ Criptografia de credenciais
- ✅ Configuração via variáveis de ambiente

## 📦 Instalação

### 1. Criar ambiente virtual

```bash
cd backend
python -m venv venv

# Linux/Mac
source venv/bin/activate

# Windows
venv\Scripts\activate
```

### 2. Instalar dependências

```bash
pip install -r requirements.txt
```

### 3. Configurar variáveis de ambiente

Copie o arquivo `.env.example` para `.env` e configure suas credenciais:

```bash
cp .env.example .env
```

Edite o arquivo `.env`:

```env
IQ_OPTION_EMAIL=seu_email@exemplo.com
IQ_OPTION_PASSWORD=sua_senha_segura
BALANCE_TYPE=PRACTICE  # ou REAL
```

## 🎯 Uso

### Executar o sistema

```bash
python main.py
```

Ou com variáveis de ambiente inline:

```bash
IQ_OPTION_EMAIL=seu@email.com IQ_OPTION_PASSWORD=senha python main.py
```

### Conectar frontend

O sistema inicia um servidor WebSocket em `ws://localhost:8765` por padrão.

Configure o frontend para conectar neste endereço.

## 📁 Estrutura do Projeto

```
backend/
├── core/
│   ├── __init__.py
│   ├── config.py              # Configurações centralizadas
│   ├── engine.py              # Motor principal
│   └── state_manager.py       # Gerenciamento de estado
├── services/
│   ├── __init__.py
│   ├── iq_option_service.py   # Integração IQ Option
│   ├── screen_capture.py      # Captura de tela
│   ├── websocket_server.py    # Servidor WebSocket
│   └── metrics_collector.py   # Coletor de métricas
├── api/
│   ├── __init__.py
│   ├── routes.py              # Rotas da API REST
│   └── handlers.py            # Handlers HTTP
├── utils/
│   ├── __init__.py
│   ├── logger.py              # Sistema de logging
│   ├── security.py            # Segurança e criptografia
│   └── validators.py          # Validadores
├── models/
│   ├── __init__.py
│   └── trading_data.py        # Modelos de dados
├── logs/                      # Logs do sistema
├── data/                      # Dados persistentes
├── main.py                    # Entry point
├── requirements.txt           # Dependências
├── .env.example               # Exemplo de configuração
└── README.md                  # Esta documentação
```

## 🔒 Segurança

### Credenciais
- **NUNCA** commite o arquivo `.env` com credenciais reais
- Use variáveis de ambiente em produção
- Considere usar gerenciadores de secrets (AWS Secrets Manager, HashiCorp Vault)

### Criptografia
O sistema inclui utilitários de criptografia para proteger dados sensíveis:

```python
from utils.security import SecurityManager

security = SecurityManager()
encrypted = security.encrypt("dados_sensíveis")
decrypted = security.decrypt(encrypted)
```

## 📊 Logging

Logs são salvos em `logs/vfss.log` com rotação automática:

- Formato JSON estruturado para análise
- Cores no console para melhor visualização
- Rotação a cada 10MB
- Mantém 5 arquivos de backup

Níveis de log:
- **DEBUG**: Informações detalhadas de debug
- **INFO**: Informações gerais
- **WARNING**: Avisos
- **ERROR**: Erros recuperáveis
- **CRITICAL**: Erros críticos

## 🔧 Configuração Avançada

### Variáveis de Ambiente

| Variável | Descrição | Padrão |
|----------|-----------|--------|
| `IQ_OPTION_EMAIL` | Email da conta | - |
| `IQ_OPTION_PASSWORD` | Senha da conta | - |
| `BALANCE_TYPE` | Tipo de conta (PRACTICE/REAL) | PRACTICE |
| `HOST` | Host do servidor | 0.0.0.0 |
| `PORT` | Porta WebSocket | 8765 |
| `LOG_LEVEL` | Nível de log | INFO |
| `AUTO_RECONNECT` | Reconexão automática | True |
| `MAX_RECONNECT_ATTEMPTS` | Máximo de tentativas | 5 |

### Performance

Para otimizar performance:

1. **Ajustar intervalos de atualização**:
   ```env
   DATA_UPDATE_INTERVAL=1
   SCREEN_CAPTURE_INTERVAL=2
   ```

2. **Desabilitar captura de tela** se não necessário:
   ```python
   # Em engine.py, comentar:
   # await self.screen_service.start()
   ```

3. **Usar PRACTICE mode** para testes:
   ```env
   BALANCE_TYPE=PRACTICE
   ```

## 🧪 Testes

```bash
# Instalar dependências de teste
pip install pytest pytest-asyncio pytest-cov

# Executar testes
pytest

# Com cobertura
pytest --cov=. --cov-report=html
```

## 🐛 Troubleshooting

### Erro de conexão com IQ Option
- Verifique credenciais no `.env`
- Confirme que a conta está ativa
- Tente usar VPN se houver restrições regionais

### WebSocket não conecta
- Verifique se a porta 8765 está livre
- Confirme firewall não está bloqueando
- Teste com `telnet localhost 8765`

### Captura de tela falha
- Instale dependências do sistema (X11 no Linux)
- Verifique permissões de captura de tela
- Teste com `mss` manualmente

## 📝 Desenvolvimento

### Adicionar novo serviço

1. Criar arquivo em `services/`:
```python
# services/meu_servico.py
class MeuServico:
    async def start(self):
        pass
    
    async def stop(self):
        pass
```

2. Integrar no motor:
```python
# core/engine.py
from services.meu_servico import MeuServico

self.meu_servico = MeuServico()
await self.meu_servico.start()
```

### Contribuir

1. Fork o projeto
2. Crie uma branch (`git checkout -b feature/nova-funcionalidade`)
3. Commit suas mudanças (`git commit -am 'Adiciona nova funcionalidade'`)
4. Push para a branch (`git push origin feature/nova-funcionalidade`)
5. Abra um Pull Request

## 📄 Licença

Este projeto é proprietário. Todos os direitos reservados.

## 👥 Suporte

Para suporte, abra uma issue no repositório ou entre em contato com a equipe de desenvolvimento.

---

**VFSS Quantum Core v3.0.0** - Sistema de Trading de Última Geração