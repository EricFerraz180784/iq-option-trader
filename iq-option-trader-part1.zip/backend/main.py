#!/usr/bin/env python3
"""
VFSS Quantum Core v3.0.0
Sistema de Trading de Última Geração

Entry point principal do sistema
"""

import asyncio
import sys
from pathlib import Path

# Adicionar diretório raiz ao path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.engine import main

if __name__ == "__main__":
    """
    Inicia o sistema VFSS Quantum Core
    
    Para executar:
        python backend/main.py
    
    Ou com variáveis de ambiente:
        IQ_OPTION_EMAIL=seu@email.com IQ_OPTION_PASSWORD=senha python backend/main.py
    """
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\nSistema interrompido pelo usuário")
        sys.exit(0)
    except Exception as e:
        print(f"\n\nErro fatal: {str(e)}")
        sys.exit(1)